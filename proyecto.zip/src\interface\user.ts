export interface User {
    id:          number;
    username:    string;
    active:      number;
    token:       string;
}